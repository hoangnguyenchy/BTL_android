﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CuaHangBanDienThoai.Utils
{
    public class Common
    {
        public static string baseUrl = "https://localhost:44362/";
    }
}